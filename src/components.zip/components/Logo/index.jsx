import DSF from "../../images/DSF_Logo.png";
const Logo = () => {
  return (
    <img src={DSF} className="App-logo" alt="logo" title="Target Ready Logo" />
  );
};
export default Logo;

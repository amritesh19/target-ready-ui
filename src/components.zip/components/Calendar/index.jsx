import { styled } from "@mui/material/styles";
import { Tabs, Tab, Box } from "@mui/material";
import { useContext } from "react";
import React, { useState, useEffect } from "react";
import { UserContext } from "../UserContext";
import DayView from "../DayView";
import WeeklyView from "../WeeklyView";
import { TabList } from "@mui/lab";
import axios from "axios";
import { useAlert } from "../AlertContext";
import { SelectedClassContext } from "../SelectedClassContext";
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
}from "@mui/material";
import './index.css';


const CalendarContainer = styled(Box)({
  maxWidth: 600,
  margin: "auto",
  marginTop: "16px",
});



const Calendar = () => {
  const [data, setData] = useState([]);
  const [selectedTab, setSelectedTab] = useState(0);
  const [className, setClassName] = useState('');
  const { user, login } = useContext(UserContext);
  const alert = useAlert();
  let { selectedClass, setSelectedClass } = useContext(SelectedClassContext);



  useEffect(() => {
      fetchData();
  }, []);

  const fetchData = () => {
    try{
      axios
      .get("http://localhost:8087/class")
      .then((response) => {
        console.log(response.data);
        setData(response.data);
      })
    }catch(error) {
        console.error("Error fetching class data:", error);
    };
  };

  const handleTabChange = (event, newValue) => {
    if(selectedClass === ''){
      alert.showAlertWithMessage("Please select the class!", "error");
    }
    else{
      setSelectedTab(newValue);
    }
  };

  const handleSelectChange = (event) => {
    setSelectedClass(event.target.value);
  };

  return (
    <CalendarContainer>

      <FormControl className="form-control">
        <select value={selectedClass} onChange={handleSelectChange} PaperProps={{className: 'select-style' }}>
            <option value="">Select Class</option>
            {data.map(item => (
              <option key={item.classId}>
                {item.className + ' - ' + item.classSection}
              </option>
            ))}
      </select>
      </FormControl>
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        indicatorColor="primary"
        textColor="primary"
        centered
      >
        {/* <TabList> */}
        <Tab label="Day View" />
        <Tab label="Week View" />
        {/* </TabList> */}
      </Tabs>
      {selectedTab === 0 && <DayView />}
      {selectedTab === 1 && <WeeklyView />}
    </CalendarContainer>
  );
}

export default Calendar;


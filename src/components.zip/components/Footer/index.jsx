
const Footer = () => {
  return (
    <>
      <footer className="App-footer">
        <a href="/about">About US</a>
        <a href="/contact">Contact US</a>
      </footer>
    </>
  );
};
export default Footer

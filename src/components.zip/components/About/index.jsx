import { Card } from "@mui/material"

const About = () => {
    return (
        <Card className="App-Card">
            <h3>About</h3>
        </Card>
    )
}
export default About
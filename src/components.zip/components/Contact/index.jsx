import { Card } from "@mui/material"

const Contact = () => {
    return (
        <Card className="App-Card">
            <h3>Contact</h3>
        </Card>
    )
}
export default Contact